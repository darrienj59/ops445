﻿namespace Microsoft.eShopWeb.Web.Pages;

public class SettingsViewModel
{
    public string? NoResultsMessage { get; set; }
}
